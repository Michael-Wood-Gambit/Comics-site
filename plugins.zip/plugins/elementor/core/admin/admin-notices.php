<?php
namespace Elementor\Core\Admin;

use Elementor\Api;
use Elementor\Core\Admin\UI\Components\Button;
use Elementor\Core\Base\Module;
use Elementor\Core\Utils\Hints;
use Elementor\Core\Utils\Promotions\Filtered_Promotions_Manager;
use Elementor\Plugin;
use Elementor\Tracker;
use Elementor\User;
use Elementor\Utils;
use Elementor\Core\Admin\Notices\Base_Notice;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Admin_Notices extends Module {

	const DEFAULT_EXCLUDED_PAGES = [ 'plugins.php', 'plugin-install.php', 'plugin-editor.php' ];

	const EXIT_EARLY_FOR_BACKWARD_COMPATIBILITY = false;

	private $plain_notices = [
		'api_notice',
		'api_upgrade_plugin',
		'tracker',
		'tracker_last_update',
		'rate_us_feedback',
		'role_manager_promote',
		'plugin_image_optimization',
		'ally_pages_promotion',
	];

	private $elementor_pages_count = null;

	private $install_time = null;

	private $current_screen_id = null;

	private function get_notices() {
		/**
		 * Admin notices.
		 *
		 * Filters Elementor admin notices.
		 *
		 * This hook can be used by external developers to manage existing
		 * admin notice or to add new notices for Elementor add-ons.
		 *
		 * @param array $notices A list of notice classes.
		 */
		$notices = apply_filters( 'elementor/core/admin/notices', [] );

		return $notices;
	}

	private function get_install_time() {
		if ( null === $this->install_time ) {
			$this->install_time = Plugin::$instance->get_install_time();
		}

		return $this->install_time;
	}

	private function get_elementor_pages_count() {
		if ( null === $this->elementor_pages_count ) {
			$elementor_pages = new \WP_Query( [
				'no_found_rows' => true,
				'post_type' => 'any',
				'post_status' => 'publish',
				'fields' => 'ids',
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'meta_key' => '_elementor_edit_mode',
				'meta_value' => 'builder',
			] );

			$this->elementor_pages_count = $elementor_pages->post_count;
		}

		return $this->elementor_pages_count;
	}

	private function notice_api_upgrade_plugin() {
		$upgrade_notice = Api::get_upgrade_notice();
		if ( empty( $upgrade_notice ) ) {
			return false;
		}

		if ( ! current_user_can( 'update_plugins' ) ) {
			return false;
		}

		if ( ! $this->is_elementor_admin_screen_with_system_info() ) {
			return false;
		}

		// Check for upgrades.
		$update_plugins = get_site_transient( 'update_plugins' );

		$has_remote_update_package = ! ( empty( $update_plugins ) || empty( $update_plugins->response[ ELEMENTOR_PLUGIN_BASE ] ) || empty( $update_plugins->response[ ELEMENTOR_PLUGIN_BASE ]->package ) );

		if ( ! $has_remote_update_package && empty( $upgrade_notice['update_link'] ) ) {
			return false;
		}

		if ( $has_remote_update_package ) {
			$product = $update_plugins->response[ ELEMENTOR_PLUGIN_BASE ];

			$details_url = self_admin_url( 'plugin-install.php?tab=plugin-information&plugin=' . $product->slug . '&section=changelog&TB_iframe=true&width=600&height=800' );
			$upgrade_url = wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . ELEMENTOR_PLUGIN_BASE ), 'upgrade-plugin_' . ELEMENTOR_PLUGIN_BASE );
			$new_version = $product->new_version;
		} else {
			$upgrade_url = $upgrade_notice['update_link'];
			$details_url = $upgrade_url;

			$new_version = $upgrade_notice['version'];
		}

		// Check if upgrade messages should be shown.
		if ( version_compare( ELEMENTOR_VERSION, $upgrade_notice['version'], '>=' ) ) {
			return false;
		}

		$notice_id = 'upgrade_notice_' . $upgrade_notice['version'];
		if ( User::is_user_notice_viewed( $notice_id ) ) {
			return false;
		}

		$message = sprintf(
			/* translators: 1: Details URL, 2: Accessibility text, 3: Version number, 4: Update URL, 5: Accessibility text. */
			__( 'There is a new version of Elementor Page Builder available. <a href="%1$s" class="thickbox open-plugin-details-modal" aria-label="%2$s">View version %3$s details</a> or <a href="%4$s" class="update-link" aria-label="%5$s">update now</a>.', 'elementor' ),
			esc_url( $details_url ),
			sprintf(
				/* translators: %s: Elementor version. */
				esc_attr__( 'View Elementor version %s details', 'elementor' ),
				$new_version
			),
			$new_version,
			esc_url( $upgrade_url ),
			esc_attr__( 'Update Now', 'elementor' )
		);

		$options = [
			'title' => esc_html__( 'Update Notification', 'elementor' ),
			'description' => $message,
			'button' => [
				'icon_classes' => 'dashicons dashicons-update',
				'text' => esc_html__( 'Update Now', 'elementor' ),
				'url' => $upgrade_url,
			],
			'id' => $notice_id,
		];

		$this->print_admin_notice( $options );

		return true;
	}

	private function notice_api_notice() {
		$admin_notice = Api::get_admin_notice();
		if ( empty( $admin_notice ) ) {
			return false;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		if ( ! $this->is_elementor_admin_screen_with_system_info() ) {
			return false;
		}

		$notice_id = 'admin_notice_api_' . $admin_notice['notice_id'];
		if ( User::is_user_notice_viewed( $notice_id ) ) {
			return false;
		}

		$options = [
			'title' => esc_html__( 'Update Notification', 'elementor' ),
			'description' => $admin_notice['notice_text'],
			'id' => $notice_id,
		];

		$this->print_admin_notice( $options );

		return true;
	}

	private function notice_tracker() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		// Show tracker notice after 24 hours from installed time.
		if ( strtotime( '+24 hours', $this->get_install_time() ) > time() ) {
			return false;
		}

		if ( '1' === get_option( 'elementor_tracker_notice' ) ) {
			return false;
		}

		if ( Tracker::is_allow_track() ) {
			return false;
		}

		if ( 2 > $this->get_elementor_pages_count() ) {
			return false;
		}

		// TODO: Skip for development env.
		$optin_url = wp_nonce_url( add_query_arg( 'elementor_tracker', 'opt_into' ), 'opt_into' );
		$optout_url = wp_nonce_url( add_query_arg( 'elementor_tracker', 'opt_out' ), 'opt_out' );

		$tracker_description_text = esc_html__( 'Become a super contributor by helping us understand how you use our service to enhance your experience and improve our product.', 'elementor' );

		/**
		 * Tracker admin description text.
		 *
		 * Filters the admin notice text for non-sensitive data collection.
		 *
		 * @since 1.0.0
		 *
		 * @param string $tracker_description_text Description text displayed in admin notice.
		 */
		$tracker_description_text = apply_filters( 'elementor/tracker/admin_description_text', $tracker_description_text );

		$message = esc_html( $tracker_description_text ) . ' <a href="https://go.elementor.com/usage-data-tracking/" target="_blank">' . esc_html__( 'Learn more.', 'elementor' ) . '</a>';

		$options = [
			'title' => esc_html__( 'Want to shape the future of web creation?', 'elementor' ),
			'description' => $message,
			'dismissible' => false,
			'button' => [
				'text' => esc_html__( 'Sure! I\'d love to help', 'elementor' ),
				'url' => $optin_url,
				'type' => 'cta',
			],
			'button_secondary' => [
				'text' => esc_html__( 'No thanks', 'elementor' ),
				'url' => $optout_url,
				'variant' => 'outline',
				'type' => 'cta',
			],
		];

		$this->print_admin_notice( $options );

		return true;
	}

	private function notice_tracker_last_update() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		if ( ! Tracker::has_terms_changed() ) {
			return false;
		}

		$notice_id = 'tracker_last_update_' . Tracker::LAST_TERMS_UPDATED;

		if ( User::is_user_notice_viewed( $notice_id ) ) {
			return false;
		}

		$optin_url = wp_nonce_url( add_query_arg( 'elementor_tracker', 'opt_into' ), 'opt_into' );

		$message = esc_html__( 'We\'re updating our Terms and Conditions to include the collection of usage and behavioral data. This information helps us understand how you use Elementor so we can make informed improvements to the product.', 'elementor' );

		$options = [
			'id' => $notice_id,
			'title' => esc_html__( 'Update regarding usage data collection', 'elementor' ),
			'description' => $message,
			'button' => [
				'text' => esc_html__( 'Opt in', 'elementor' ),
				'url' => $optin_url,
				'type' => 'cta',
			],
			'button_secondary' => [
				'text' => esc_html__( 'Learn more', 'elementor' ),
				'url' => 'https://go.elementor.com/wp-dash-update-usage-notice/',
				'new_tab' => true,
				'type' => 'cta',
			],
		];

		$this->print_admin_notice( $options );

		return true;
	}

	private function notice_rate_us_feedback() {
		$notice_id = 'rate_us_feedback';

		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		if ( 'dashboard' !== $this->current_screen_id || User::is_user_notice_viewed( $notice_id ) ) {
			return false;
		}

		if ( 10 >= $this->get_elementor_pages_count() ) {
			return false;
		}

		$dismiss_url = add_query_arg( [
			'action' => 'elementor_set_admin_notice_viewed',
			'notice_id' => esc_attr( $notice_id ),
			'_wpnonce' => wp_create_nonce( 'elementor_set_admin_notice_viewed' ),
		], admin_url( 'admin-post.php' ) );

		$options = [
			'title' => esc_html__( 'Congrats!', 'elementor' ),
			'description' => esc_html__( 'You created over 10 pages with Elementor. Great job! If you can spare a minute, please help us by leaving a five star review on WordPress.org.', 'elementor' ),
			'id' => $notice_id,
			'button' => [
				'text' => esc_html__( 'Happy To Help', 'elementor' ),
				'url' => 'https://go.elementor.com/admin-review/',
				'new_tab' => true,
				'type' => 'cta',
			],
			'button_secondary' => [
				'text' => esc_html__( 'Hide Notification', 'elementor' ),
				'classes' => [ 'e-notice-dismiss' ],
				'url' => esc_url_raw( $dismiss_url ),
				'new_tab' => true,
				'type' => 'cta',
			],
		];

		$this->print_admin_notice( $options );

		return true;
	}

	private function notice_role_manager_promote() {
		$notice_id = 'role_manager_promote';

		if ( Utils::has_pro() ) {
			return false;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		if ( 'elementor_page_elementor-role-manager' !== $this->current_screen_id || User::is_user_notice_viewed( $notice_id ) ) {
			return false;
		}

		$users = new \WP_User_Query( [
			'fields' => 'ID',
			'number' => 10,
		] );

		if ( 5 > $users->get_total() ) {
			return false;
		}

		$options = [
			'title' => esc_html__( 'Managing a multi-user site?', 'elementor' ),
			'description' => esc_html__( 'With Elementor Pro, you can control user access and make sure no one messes up your design.', 'elementor' ),
			'id' => $notice_id,

			'button' => [
				'text' => esc_html__( 'Learn More', 'elementor' ),
				'url' => 'https://go.elementor.com/plugin-promotion-role-manager/',
				'new_tab' => true,
				'type' => 'cta',
			],
		];

		$options = Filtered_Promotions_Manager::get_filtered_promotion_data( $options, 'core/admin/notice_role_manager_promote', 'button', 'url' );

		$this->print_admin_notice( $options );

		return true;
	}

	private function get_installed_form_plugin_name() {
		static $detected_form_plugin = null;

		if ( null !== $detected_form_plugin ) {
			return $detected_form_plugin;
		}

		$form_plugins_constants_to_name_mapper = [
			'WPFORMS_VERSION' => 'WPForms',
			'WPCF7_VERSION' => 'Contact Form 7',
		];

		foreach ( $form_plugins_constants_to_name_mapper as $constant => $name ) {
			if ( defined( $constant ) ) {
				$detected_form_plugin = $name;
				return $detected_form_plugin;
			}
		}

		$form_plugins_classes_to_name_mapper = [
			'\GFCommon' => 'Gravity Forms',
			'\Ninja_Forms' => 'Ninja Forms',
		];

		foreach ( $form_plugins_classes_to_name_mapper as $class => $name ) {
			if ( class_exists( $class ) ) {
				$detected_form_plugin = $name;
				return $detected_form_plugin;
			}
		}

		$detected_form_plugin = false;
		return $detected_form_plugin;
	}

	private function notice_ally_pages_promotion() {
		global $pagenow;
		$notice_id = 'ally_pages_promotion';

		if ( 'edit.php' !== $pagenow || empty( $_GET['post_type'] ) || 'page' !== $_GET['post_type'] ) {
			return false;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		if ( User::is_user_notice_viewed( $notice_id ) ) {
			return false;
		}

		$plugin_slug = 'pojo-accessibility';
		$plugin_file_path = 'pojo-accessibility/pojo-accessibility.php';

		$one_subscription = Hints::is_plugin_connected_to_one_subscription();
		$is_installed = Hints::is_plugin_installed( $plugin_slug );
		$is_active = Hints::is_plugin_active( $plugin_slug );

		if ( $is_active ) {
			return false;
		}

		if ( $one_subscription ) {
			$learn_more_url = 'https://go.elementor.com/acc-plg-learn-more-one';

			if ( ! $is_installed ) {
				$description = esc_html__( 'Make sure your site has an accessibility statement page. Install Web Accessibility, included in ONE, to create it in a few clicks.', 'elementor' );
				$button_text = esc_html__( 'Install now', 'elementor' );
				$button_url = $this->get_plugin_button_install_url( $plugin_slug );
				$campaign_data = [
					'name' => 'elementor_ea11y_campaign',
					'campaign' => 'acc-statement-plg-pages-one-install',
					'source' => 'wp-pages-one-install',
					'medium' => 'wp-dash-one',
				];
			} elseif ( ! $is_active ) {
				$description = esc_html__( 'Your ONE subscription includes Web Accessibility. Activate it to create your accessibility statement page quickly.', 'elementor' );
				$button_text = esc_html__( 'Activate now', 'elementor' );
				$button_url = $this->get_plugin_button_activate_url( $plugin_file_path );
				$campaign_data = [
					'name' => 'elementor_ea11y_campaign',
					'campaign' => 'acc-statement-plg-pages-one-activate',
					'source' => 'wp-pages-one-activate',
					'medium' => 'wp-dash-one',
				];
			}
		} else {
			$description = esc_html__( "Create a more inclusive site experience for all your visitors. With Web Accessibility, it's easy to add your statement page in just a few clicks.", 'elementor' );
			$learn_more_url = 'https://go.elementor.com/acc-plg-learn-more';

			if ( ! $is_installed ) {
				$button_text = esc_html__( 'Install now', 'elementor' );
				$button_url = $this->get_plugin_button_install_url( $plugin_slug );
				$campaign_data = [
					'name' => 'elementor_ea11y_campaign',
					'campaign' => 'acc-statement-plg-pages-install',
					'source' => 'wp-pages-install',
					'medium' => 'wp-dash',
				];
			} elseif ( ! $is_active ) {
				$button_text = esc_html__( 'Activate now', 'elementor' );
				$button_url = $this->get_plugin_button_activate_url( $plugin_file_path );
				$campaign_data = [
					'name' => 'elementor_ea11y_campaign',
					'campaign' => 'acc-statement-plg-pages-activate',
					'source' => 'wp-pages-activate',
					'medium' => 'wp-dash',
				];
			}
		}

		$options = [
			'title' => esc_html__( 'Make sure your site has an accessibility statement page', 'elementor' ),
			'description' => $description,
			'id' => $notice_id,
			'type' => 'cta',
			'button' => [
				'text' => $button_text,
				'url' => self::add_plg_campaign_data( $button_url, $campaign_data ),
				'type' => 'cta',
			],
			'button_secondary' => [
				'text' => esc_html__( 'Learn more', 'elementor' ),
				'url' => $learn_more_url,
				'new_tab' => true,
				'type' => 'cta',
			],
		];

		$this->print_admin_notice( $options );

		return true;
	}

	private function is_elementor_page(): bool {
		return 0 === strpos( $this->current_screen_id, 'elementor_page' );
	}

	private function is_elementor_admin_screen(): bool {
		return in_array( $this->current_screen_id, [ 'toplevel_page_elementor', 'edit-elementor_library' ], true );
	}

	private function is_elementor_admin_screen_with_system_info(): bool {
		return in_array( $this->current_screen_id, [ 'toplevel_page_elementor', 'edit-elementor_library', 'elementor_page_elementor-system-info', 'dashboard' ], true );
	}
	private function get_plugin_button_install_url( $plugin_slug ) {
		return wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=' . $plugin_slug ), 'install-plugin_' . $plugin_slug );
	}

	private function get_plugin_button_activate_url( $plugin_file_path ) {
		return wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin_file_path . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin_file_path );
	}

	private function get_plugin_button_connect_url( $plugin_settings_page ) {
		return self_admin_url( $plugin_settings_page );
	}

	private function get_plugin_cta_data( $plugin_slug, $plugin_file_path ) {
		if ( Hints::is_plugin_active( $plugin_slug ) ) {
			return false;
		}

		if ( Hints::is_plugin_installed( $plugin_slug ) ) {
			$url = $this->get_plugin_button_activate_url( $plugin_file_path );
			$cta_text = esc_html__( 'Activate now', 'elementor' );
		} else {
			$url = $this->get_plugin_button_install_url( $plugin_slug );
			$cta_text = esc_html__( 'Install now', 'elementor' );
		}

		return [
			'url' => $url,
			'text' => $cta_text,
		];
	}

	/**
	 * For testing purposes
	 */
	public function get_elementor_version() {
		return ELEMENTOR_VERSION;
	}

	private function notice_plugin_image_optimization() {
		$notice_id = 'plugin_image_optimization';

		if ( 'upload' !== $this->current_screen_id ) {
			return false;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		if ( User::is_user_notice_viewed( $notice_id ) ) {
			return false;
		}

		$attachments = new \WP_Query( [
			'post_type' => 'attachment',
			'post_status' => 'any',
			'fields' => 'ids',
		] );

		if ( 1 > $attachments->found_posts ) {
			return false;
		}

		$plugin_slug = 'image-optimization';
		$plugin_file_path = 'image-optimization/image-optimization.php';

		$one_subscription = Hints::is_plugin_connected_to_one_subscription();
		$is_installed = Hints::is_plugin_installed( $plugin_slug );
		$is_active = Hints::is_plugin_active( $plugin_slug );

		if ( $is_active ) {
			return false;
		}

		if ( $one_subscription ) {
			if ( ! $is_installed ) {
				$description = esc_html__( 'Automatically optimize images to improve site speed and performance. Included with your ONE subscription.', 'elementor' );
				$button_text = esc_html__( 'Install now', 'elementor' );
				$button_url = $this->get_plugin_button_install_url( $plugin_slug );
				$campaign_data = [
					'name' => 'elementor_image_optimization_campaign',
					'campaign' => 'io-plg-one',
					'source' => 'io-wp-media-library-one-install',
					'medium' => 'wp-dash-one',
				];
			} elseif ( ! $is_active ) {
				$description = esc_html__( 'Your ONE subscription includes Image Optimization. Activate it to optimize images and improve site performance.', 'elementor' );
				$button_text = esc_html__( 'Activate now', 'elementor' );
				$button_url = $this->get_plugin_button_activate_url( $plugin_file_path );
				$campaign_data = [
					'name' => 'elementor_image_optimization_campaign',
					'campaign' => 'io-plg-one',
					'source' => 'io-wp-media-library-one-activate',
					'medium' => 'wp-dash-one',
				];
			}
		} else {
			$description = esc_html__( 'Automatically compress and optimize images, resize larger files, or convert to WebP. Optimize images individually, in bulk, or on upload.', 'elementor' );

			if ( ! $is_installed ) {
				$button_text = esc_html__( 'Install now', 'elementor' );
				$button_url = $this->get_plugin_button_install_url( $plugin_slug );
				$campaign_data = [
					'name' => 'elementor_image_optimization_campaign',
					'campaign' => 'io-plg',
					'source' => 'io-wp-media-library-install',
					'medium' => 'wp-dash',
				];
			} elseif ( ! $is_active ) {
				$button_text = esc_html__( 'Activate now', 'elementor' );
				$button_url = $this->get_plugin_button_activate_url( $plugin_file_path );
				$campaign_data = [
					'name' => 'elementor_image_optimization_campaign',
					'campaign' => 'io-plg',
					'source' => 'io-wp-media-library-activate',
					'medium' => 'wp-dash',
				];
			}
		}

		$options = [
			'title' => esc_html__( 'Speed up your website with Image Optimization', 'elementor' ),
			'description' => $description,
			'id' => $notice_id,
			'type' => 'cta',
			'button' => [
				'text' => $button_text,
				'url' => self::add_plg_campaign_data( $button_url, $campaign_data ),
				'type' => 'cta',
				'data' => [
					'campaign' => $campaign_data['campaign'],
					'source' => $campaign_data['source'],
					'medium' => $campaign_data['medium'],
				],
			],
		];

		$this->print_admin_notice( $options );

		return true;
	}

	public function print_admin_notice( array $options, $exclude_pages = self::DEFAULT_EXCLUDED_PAGES ) {
		global $pagenow;

		if ( in_array( $pagenow, $exclude_pages, true ) ) {
			return;
		}

		$default_options = [
			'id' => null,
			'title' => '',
			'description' => '',
			'classes' => [ 'notice', 'e-notice' ], // We include WP's default notice class so it will be properly handled by WP's js handler
			'type' => '',
			'dismissible' => true,
			'icon' => 'eicon-elementor-circle',
			'button' => [],
			'button_secondary' => [],
		];

		$options = array_replace_recursive( $default_options, $options );

		$notice_classes = $options['classes'];
		$dismiss_button = '';
		$icon = '';

		if ( $options['type'] ) {
			$notice_classes[] = 'e-notice--' . $options['type'];
		}

		$wrapper_attributes = [
			'role' => 'region',
			'aria-label' => esc_html__( 'Elementor notice', 'elementor' ),
		];

		if ( $options['dismissible'] ) {
			$label = esc_html__( 'Dismiss this notice.', 'elementor' );
			$notice_classes[] = 'e-notice--dismissible';
			$dismiss_button = '<i class="e-notice__dismiss" role="button" aria-label="' . $label . '" tabindex="0"></i>';

			$wrapper_attributes['data-nonce'] = wp_create_nonce( 'elementor_set_admin_notice_viewed' );
		}

		if ( $options['icon'] ) {
			$notice_classes[] = 'e-notice--extended';
			$icon = '<div class="e-notice__icon-wrapper"><i class="' . esc_attr( $options['icon'] ) . '" aria-hidden="true"></i></div>';
		}

		$wrapper_attributes['class'] = $notice_classes;

		if ( $options['id'] ) {
			$wrapper_attributes['data-notice_id'] = $options['id'];
		}

		if ( ! empty( $options['source'] ) ) {
			$wrapper_attributes['data-source'] = $options['source'];
		}
		?>
		<div <?php Utils::print_html_attributes( $wrapper_attributes ); ?>>
			<?php echo $dismiss_button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<div class="e-notice__aside">
				<?php echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
			<div class="e-notice__content">
				<?php if ( $options['title'] ) { ?>
					<h3><?php echo wp_kses_post( $options['title'] ); ?></h3>
				<?php } ?>

				<?php if ( $options['description'] ) { ?>
					<p><?php echo wp_kses_post( $options['description'] ); ?></p>
				<?php } ?>

				<?php if ( ! empty( $options['button']['text'] ) || ! empty( $options['button_secondary']['text'] ) ) { ?>
					<div class="e-notice__actions">
						<?php
						$one_subscription = Hints::is_plugin_connected_to_one_subscription();
						foreach ( [ $options['button'], $options['button_secondary'] ] as $index => $button_settings ) {
							if ( empty( $button_settings['variant'] ) && $index ) {
								$button_settings['variant'] = 'outline';
							}

							if ( empty( $button_settings['text'] ) ) {
								continue;
							}

							if ( $one_subscription ) {
								if ( ! isset( $button_settings['classes'] ) ) {
									$button_settings['classes'] = [];
								}
								if ( ! is_array( $button_settings['classes'] ) ) {
									$button_settings['classes'] = [ $button_settings['classes'] ];
								}
								// index 0 = button, index 1 = button_secondary
								$button_class = ( 0 === $index ) ? 'button-primary' : 'button-secondary';
								$button_settings['classes'][] = $button_class;
							}

							$button = new Button( $button_settings );
							$button->print_button();
						} ?>
					</div>
				<?php } ?>
			</div>
		</div>
	<?php }

	public function admin_notices() {
		$this->install_time = Plugin::$instance->get_install_time();
		$this->current_screen_id = get_current_screen()->id;

		foreach ( $this->plain_notices as $notice ) {
			$method_callback = "notice_{$notice}";
			if ( $this->$method_callback() ) {
				return;
			}
		}

		/** @var Base_Notice $notice_instance */
		foreach ( $this->get_notices() as $notice_instance ) {
			if ( ! $notice_instance->should_print() ) {
				continue;
			}

			$this->print_admin_notice( $notice_instance->get_config() );

			// It exits the method to make sure it prints only one notice.
			return;
		}
	}

	public function maybe_log_campaign() {
		if ( empty( $_GET['plg_campaign'] ) || empty( $_GET['plg_campaign_name'] ) ) {
			return;
		}

		$allowed_plgs = [
			'elementor_image_optimization_campaign',
			'elementor_ea11y_campaign',
		];

		if ( ! in_array( $_GET['plg_campaign_name'], $allowed_plgs, true ) ) {
			return;
		}

		if ( ! isset( $_GET['plg_campaign_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_GET['plg_campaign_nonce'] ), sanitize_key( $_GET['plg_campaign_name'] ) ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( empty( $_GET['plg_source'] ) || empty( $_GET['plg_medium'] ) ) {
			return;
		}

		$campaign_data = [
			'source' => sanitize_key( $_GET['plg_source'] ),
			'campaign' => sanitize_key( $_GET['plg_campaign'] ),
			'medium' => sanitize_key( $_GET['plg_medium'] ),
		];

		set_transient( sanitize_key( $_GET['plg_campaign_name'] ), $campaign_data, 30 * DAY_IN_SECONDS );
	}

	public static function add_plg_campaign_data( $url, $campaign_data ) {

		foreach ( [ 'name', 'campaign' ] as $key ) {
			if ( empty( $campaign_data[ $key ] ) ) {
				return $url;
			}
		}

		return add_query_arg( [
			'plg_campaign_name' => $campaign_data['name'],
			'plg_campaign' => $campaign_data['campaign'],
			'plg_source' => empty( $campaign_data['source'] ) ? '' : $campaign_data['source'],
			'plg_medium' => empty( $campaign_data['medium'] ) ? '' : $campaign_data['medium'],
			'plg_campaign_nonce' => wp_create_nonce( $campaign_data['name'] ),
		], $url );
	}

	/**
	 * @since 2.9.0
	 * @access public
	 */
	public function __construct() {
		add_action( 'admin_notices', [ $this, 'admin_notices' ], 20 );
		add_action( 'admin_action_install-plugin', [ $this, 'maybe_log_campaign' ] );
		add_action( 'admin_action_activate', [ $this, 'maybe_log_campaign' ] );
	}

	/**
	 * Get module name.
	 *
	 * Retrieve the module name.
	 *
	 * @since  2.9.0
	 * @access public
	 *
	 * @return string Module name.
	 */
	public function get_name() {
		return 'admin-notices';
	}
}
