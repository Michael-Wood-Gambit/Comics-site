__( 'Name your page', 'elementor' );
__( 'To proceed, please name your first page,', 'elementor' );
__( 'or rename it later.', 'elementor' );
__( 'New Page', 'elementor' );
__( 'Cancel', 'elementor' );
__( 'Save', 'elementor' );
__( 'Quick Start', 'elementor' );
__( 'Edit site', 'elementor' );
__( "We couldn't load this content right now. Please try again later.", 'elementor' );