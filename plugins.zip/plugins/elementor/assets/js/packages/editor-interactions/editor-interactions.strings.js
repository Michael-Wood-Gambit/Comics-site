__( 'Elements', 'elementor' );
__( 'Interactions Pasted', 'elementor' );
__( 'From top', 'elementor' );
__( 'To top', 'elementor' );
__( 'From bottom', 'elementor' );
__( 'To bottom', 'elementor' );
__( 'From left', 'elementor' );
__( 'To left', 'elementor' );
__( 'From right', 'elementor' );
__( 'To right', 'elementor' );
__( 'Ease In', 'elementor' );
__( 'Ease In Out', 'elementor' );
__( 'Ease Out', 'elementor' );
__( 'Back In', 'elementor' );
__( 'Back In Out', 'elementor' );
__( 'Back Out', 'elementor' );
__( 'Linear', 'elementor' );
__( 'Upgrade to control the smoothness of the interaction.', 'elementor' );
__( 'In', 'elementor' );
__( 'In', 'elementor' );
__( 'Out', 'elementor' );
__( 'Out', 'elementor' );
__( 'Fade', 'elementor' );
__( 'Slide', 'elementor' );
__( 'Scale', 'elementor' );
__( 'Custom', 'elementor' );
__( 'PRO effects', 'elementor' );
__(
				'Upgrade to further customize your animation with opacity, scale, move, rotate and more.',
				'elementor'
			);
__( 'times', 'elementor' );
__( 'loop', 'elementor' );
__( 'Enable number', 'elementor' );
__( 'Infinite repeat', 'elementor' );
__( 'Upgrade to control how many times the animation repeats.', 'elementor' );
__( 'No', 'elementor' );
__( 'Yes', 'elementor' );
__( 'Upgrade to run the animation every time its trigger occurs.', 'elementor' );
__( 'Page load', 'elementor' );
__( 'Scroll into view', 'elementor' );
__( 'While scrolling', 'elementor' );
__( 'On hover', 'elementor' );
__( 'On click', 'elementor' );
__( 'PRO triggers', 'elementor' );
__( 'Upgrade to unlock more interactions triggers.', 'elementor' );
__( 'Animate elements with Interactions', 'elementor' );
__(
					'Add entrance animations and effects triggered by user interactions such as page load or scroll.',
					'elementor'
				);
__( 'Create an interaction', 'elementor' );
__( 'Trigger', 'elementor' );
__( 'Replay', 'elementor' );
__( 'Effect', 'elementor' );
__( 'Custom Effect', 'elementor' );
__( 'Type', 'elementor' );
__( 'Direction', 'elementor' );
__( 'Repeat', 'elementor' );
__( 'Times', 'elementor' );
__( 'Duration', 'elementor' );
__( 'Delay', 'elementor' );
__( 'Start', 'elementor' );
__( 'End', 'elementor' );
__( 'Relative To', 'elementor' );
__( 'Easing', 'elementor' );
__( 'Trigger on', 'elementor' );
__( 'Interaction', 'elementor' );
__( 'Details', 'elementor' );
__( 'Settings', 'elementor' );
__( 'Interactions', 'elementor' );
__(
					"You've reached the limit of 5 interactions for this element. Please remove an interaction before creating a new one.",
					'elementor'
				);
__( 'Interactions', 'elementor' );
__( 'Preview', 'elementor' );
__( 'Play interaction', 'elementor' );
__( 'Interaction Applied', 'elementor' );
__( 'Interaction Deleted', 'elementor' );
__( 'Interactions', 'elementor' );
__( 'Upgrade now', 'elementor' );
__( 'PRO features', 'elementor' );